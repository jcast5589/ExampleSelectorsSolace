package com.example2.sub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubApplicationTests {

	@Test
	void contextLoads() {
	}

}
