package com.example1.pub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PubApplicationTests {

	@Test
	void contextLoads() {
	}

}
